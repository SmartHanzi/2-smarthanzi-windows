﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace SmartHanzi
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {

        private void Application_Startup(object sender, StartupEventArgs args)
        {
            // Clear current resource dictionaries
            Resources.MergedDictionaries.Clear();

            // Add resource dictionaries for current language
            ResourceDictionary rd = new ResourceDictionary();
            rd.Source = new Uri("/_Langs/" + Settings.Default.Lang + "/Dictionary.xaml", UriKind.Relative);
            Resources.MergedDictionaries.Add(rd);
        }
    }
}
