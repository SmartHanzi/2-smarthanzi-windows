﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

using SmartHanzi.About;
using SmartHanzi.Home;
using SmartHanzi.Search;

namespace SmartHanzi
{
    public partial class App
    {
        #region Initialization

        #endregion Initialization

        #region Termination

        #region Exit

        void Application_Exit(object sender, ExitEventArgs e)
        {
            // Save settings
            Settings.Default.Save();

            // Save ratings
            // RatingsTools.Save();

            // Save history
            // HistoryTools.Save();
        }

        #endregion

        public void SetLang(string lang)
        {
            // Ignore if lang doesn't change
            if (lang == Settings.Default.Lang)
                return;

            // Warn user
            string msg;
            switch (lang)
            {
                case "fr":
                    msg = "L'application va redémarrer.";
                    break;

                case "en":
                default:
                    msg = "Application will restart.";
                    break;
            }

            // Warn user
            MessageBox.Show(msg, MainWindow.Title, MessageBoxButton.OK, MessageBoxImage.Information);

            // Save new LANG
            Settings.Default.Lang = lang;
            Settings.Default.Save();

            // DEBUG To be checked
            string location = Application.ResourceAssembly.Location;
            location = location.Replace("dll", "exe");

            // Start new app and kill current one
            System.Diagnostics.Process.Start(location);
            Environment.Exit(0);
        }

        #endregion // Termination

        #region About

        AboutView m_aboutView;

        public async Task ShowAboutViewAsync()
        {
            // Create SearchView if not yet done;
            if (m_aboutView == null)
                m_aboutView = AboutView.Create();

            // Show view
            await ViewController.SetMasterViewAsync(m_aboutView);
        }

        #endregion Search

        #region Home

        HomeViewBase m_homeView;

        public async Task ShowHomeViewAsync()
        {
            // Create view if not yet done
            if (m_homeView == null)
            {
                if (Settings.Default.Lang == "fr")
                    m_homeView = new Home.fr.HomeView();
                else
                    m_homeView = new Home.en.HomeView();
            }

            // Show view
            await ViewController.SetMasterViewAsync(m_homeView);
        }

        #endregion // Home

        #region Search

        SearchView m_searchView;

        public async Task ShowSearchViewAsync()
        {
            // Create SearchView if not yet done;
            if (m_searchView == null)
                m_searchView = new SearchView();

            // Show view
            await ViewController.SetMasterViewAsync(m_searchView);
        }

        #endregion Search
    }
}
