﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SmartHanzi.About
{
    /// <summary>
    /// Interaction logic for AboutView.xaml
    /// </summary>
    public partial class AboutView : UserControl
    {
        #region Initialization

        private AboutView()
        {
            InitializeComponent();
        }

        public static AboutView Create()
        {
            AboutView view = new AboutView();

            // Get HTML string
            string html = GetHtml();

            // Load HTML string
            view.WebBrowser.NavigateToString(html);

            return view;
        }

        private static string GetVersion()
        {
            string text;

            var version = Assembly.GetExecutingAssembly().GetName().Version;

            if (version.Build == 0)
                text = String.Format("{0:D}.{1:D2}", version.Major, version.Minor);
            else
                text = String.Format("{0:D}.{1:D2}.{2:D2}", version.Major, version.Minor, version.Build);

            return text;
        }

        #endregion // Initialization

        private async void WebBrowser_Navigating(object sender, NavigatingCancelEventArgs args)
        {
            // Return if no URI
            if (args.Uri == null)
                return;

            // Set CANCEL flag
            args.Cancel = true;

            // Get scheme
            string scheme = args.Uri.Scheme;

            // If not "app"
            if (scheme != "app")
            {
                // Open URL in default browser and return
                System.Diagnostics.Process.Start(args.Uri.AbsoluteUri);
                return;
            }

            // For "app://"...

            // Get URI
            Uri uri = args.Uri;

            // Get host
            string host = uri.Host;

            // Get and unescape query
            string query = args.Uri.Query;
            if (query != null && query.Length > 0)
                query = query.Substring(1);
            query = Uri.UnescapeDataString(query);

            switch (host)
            {
                case "show_credits":
                    // await App.ShowViewCreditsAsync();
                    break;

                default:
                    break;
            }
        }

    }
}
