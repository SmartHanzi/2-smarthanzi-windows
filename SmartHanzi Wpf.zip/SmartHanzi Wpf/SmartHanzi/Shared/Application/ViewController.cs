﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace SmartHanzi
{
    public static class ViewController
    {
        private static MainWindow MainWindow = App.Current.MainWindow as MainWindow;

        public static async Task SetMasterViewAsync(UserControl view)
        {

            MainWindow.MasterPane.Child = view;
        }
    }
}
