﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SmartHanzi.About
{
    /// <summary>
    /// Interaction logic for AboutView.xaml
    /// </summary>
    public partial class AboutView : UserControl
    {
        private static string GetHtml()
        {
            // Get base directroy
            string baseDir = Environment.CurrentDirectory + "/Html/lambda/";

            // Read file
            string fileName = (Settings.Default.Lang == "fr" ? "about_fr.html" : "about_en.html");
            string html = System.IO.File.ReadAllText(baseDir + fileName);

            // Replace variables
            html = html.Replace("%BASEDIR%", baseDir);
            html = html.Replace("%VERSION%", GetVersion());
            // html = html.Replace("%DICTIONARIES%", GetDictionaries());

            return html;
        }
    }
}
