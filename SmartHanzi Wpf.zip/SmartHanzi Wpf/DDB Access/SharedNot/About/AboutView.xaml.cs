﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SmartHanzi.About
{
    /// <summary>
    /// Interaction logic for AboutView.xaml
    /// </summary>
    public partial class AboutView : UserControl
    {
        #region HTML

        private static string GetHtml()
        {
            // Get base directroy
            string baseDir = Environment.CurrentDirectory + "/Html/lambda/";

            // Read file
            string html = System.IO.File.ReadAllText(baseDir + "about_en.html");

            // Get dictionary data
            // ChineseDictionary cdDDB = App.ChineseDictionaries["ddb"];
            // ChineseDictionary cdCJKVE = App.ChineseDictionaries["cjkve"];

            // Replace variables
            html = html.Replace("%BASEDIR%", baseDir);
            html = html.Replace("%VERSION%", GetVersion());
            // html = html.Replace("%DATE_DDB%", cdDDB.X.Date.ToString("d MMM yyyy", CultureInfo.InvariantCulture));
            // html = html.Replace("%DATE_CJKVE%", cdCJKVE.X.Date.ToString("d MMM yyyy", CultureInfo.InvariantCulture));
            // html = html.Replace("%DICTIONARIES%", GetDictionaries());

            return html;
        }

        #endregion // HTML
    }
}
