﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.IO;

namespace SmartHanzi
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // Show view home asap
            await App.ShowHomeViewAsync();

            string dirData = Environment.GetFolderPath(Environment.SpecialFolder.Personal) + "\\" + Settings.Default.DirSmartHanziDebug + "\\" + "cedict";

            Title = dirData;

            using (StreamReader sr = new StreamReader(dirData + "\\infos.dat"))
            {
                string line;

                line = sr.ReadLine();
                Title = line;
            }
        }
    }
}
