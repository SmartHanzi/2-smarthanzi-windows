﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;

namespace SmartHanzi
{
    public partial class MainWindow
    {
        readonly App App = Application.Current as App;

        #region Initialization

        public MainWindow()
        {
            InitializeComponent();

            // Maximize window according to setting
            if (Settings.Default.IsWindowMaximized)
                WindowState = WindowState.Maximized;
        }

        private void Window_StateChanged(object sender, EventArgs e)
        {
            if (WindowState == WindowState.Maximized)
                Settings.Default.IsWindowMaximized = true;
            else
                Settings.Default.IsWindowMaximized = false;
        }

        #endregion // Initialization

        private async void Home_Click(object sender, RoutedEventArgs e)
        {
            await App.ShowHomeViewAsync();
        }

        private async void About_Click(object sender, RoutedEventArgs e)
        {
            await App.ShowAboutViewAsync();
        }

        private void SetLangFrench_Click(object sender, RoutedEventArgs e)
        {
            App.SetLang("fr");
        }
        private void SetLangEnglish_Click(object sender, RoutedEventArgs e)
        {
            App.SetLang("en");
        }

        #region Search

        private async void Search_Click(object sender, RoutedEventArgs e)
        {
            await App.ShowSearchViewAsync();
        }

        #endregion // Search
    }
}
